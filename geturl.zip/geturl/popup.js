import { getActiveTabURL } from './background.js';

// List of social media keywords
const socialMediaKeywords = [
    'whatsapp',
    'facebook',
    'youtube',
    'instagram'
    // Add more social media keywords as needed
];

// Function to check if the URL contains social media keywords
function isSocialMedia(url) {
    console.log("in function");
    for (const keyword of socialMediaKeywords) {
        if (url.includes(keyword)) {
            return true;
        }
    }
    return false;
}

document.addEventListener('DOMContentLoaded', async () => {
    const tab = await getActiveTabURL();
    const urlDiv = document.getElementById('url');
    const socialMediaText = document.getElementById('socialMediaText');

    urlDiv.textContent = tab.url;

    // Check if the URL contains social media keywords
    const isSocial = isSocialMedia(tab.url);
    if (isSocial) {
        socialMediaText.textContent = "The URL is of a social media platform.";
    } else {
        socialMediaText.textContent = "The URL is not of a social media platform.";
    }
});
